// ============================================================
// TIMER WIDGETS – Notes, Interruption Log, Soundboard
// ============================================================

// ----- NOTES WIDGET (Floating, Collapsible) -----
(function initNotes() {
    const notesHeader = document.getElementById('notes-header');
    const notesBody = document.getElementById('notes-body');
    const notesCollapseIcon = document.getElementById('notes-collapse-icon');
    const notesInput = document.getElementById('notes-input');
    const notesList = document.getElementById('notes-list');
    const notesCount = document.getElementById('notes-count');
    const clearNotesBtn = document.getElementById('clear-notes-btn');

    if (!notesInput) return;

    let notesData = [];
    try {
        const stored = localStorage.getItem('floatingNotesData');
        notesData = stored ? JSON.parse(stored) : [];
    } catch (e) { notesData = []; }

    function renderNotes() {
        if (!notesList || !notesCount) return;
        notesCount.textContent = `(${notesData.length})`;
        if (notesData.length === 0) {
            notesList.innerHTML = '<li style="text-align:center; opacity:0.4; padding:8px 0; font-size:11px;">No notes yet</li>';
            return;
        }
        notesList.innerHTML = notesData.map((note, idx) => `
            <li style="padding: 6px 0; border-bottom: 1px solid #2a2a2a; display: flex; justify-content: space-between; align-items: center;">
                <span style="flex: 1; color: #ccc; word-break: break-word;">${escapeHtml(note.text)}</span>
                <button onclick="deleteNote(${idx})" style="background: none; border: none; color: #666; cursor: pointer; font-size: 11px; margin-left: 8px;">✕</button>
            </li>
        `).join('');
    }

    window.deleteNote = (idx) => {
        notesData.splice(idx, 1);
        localStorage.setItem('floatingNotesData', JSON.stringify(notesData));
        renderNotes();
    };

    notesInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const text = notesInput.value.trim();
            if (!text) return;
            notesData.push({ text, timestamp: Date.now() });
            localStorage.setItem('floatingNotesData', JSON.stringify(notesData));
            notesInput.value = '';
            renderNotes();
        }
    });

    if (clearNotesBtn) {
        clearNotesBtn.addEventListener('click', () => {
            if (!confirm('Clear all notes?')) return;
            notesData = [];
            localStorage.setItem('floatingNotesData', JSON.stringify(notesData));
            renderNotes();
        });
    }

    // Toggle collapse
    if (notesHeader) {
        notesHeader.addEventListener('click', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON') return;
            if (!notesBody) return;
            const isHidden = notesBody.style.display === 'none';
            notesBody.style.display = isHidden ? 'block' : 'none';
            if (notesCollapseIcon) notesCollapseIcon.textContent = isHidden ? '▲' : '▼';
        });
    }

    renderNotes();
})();

// ----- INTERRUPTION LOG -----
(function initInterruptions() {
    const input = document.getElementById('interruption-input');
    const logBtn = document.getElementById('log-interruption-btn');
    const clearBtn = document.getElementById('clear-interruptions-btn');
    const list = document.getElementById('interruption-list');
    const count = document.getElementById('interruption-count');
    if (!input) return;

    let interruptions = [];
    try {
        const stored = localStorage.getItem('interruptionLog');
        interruptions = stored ? JSON.parse(stored) : [];
    } catch (e) { interruptions = []; }

    function render() {
        if (!list || !count) return;
        count.textContent = interruptions.length === 1 ? '1 interruption' : `${interruptions.length} interruptions`;
        if (interruptions.length === 0) {
            list.innerHTML = '<li style="text-align:center; opacity:0.4; padding:8px 0; font-size:11px;">No interruptions logged yet</li>';
            return;
        }
        list.innerHTML = interruptions.map(item => `
            <li style="padding: 6px 0; border-bottom: 1px solid #2a2a2a; display: flex; justify-content: space-between; align-items: center;">
                <span style="flex: 1; color: #ccc;">${escapeHtml(item.text)}</span>
                <span style="font-size: 10px; color: #666; margin-left: 8px; white-space: nowrap;">${new Date(item.timestamp).toLocaleTimeString()}</span>
            </li>
        `).join('');
    }

    function logInterruption() {
        const text = input.value.trim();
        if (!text) return;
        interruptions.push({ text, timestamp: Date.now() });
        localStorage.setItem('interruptionLog', JSON.stringify(interruptions));
        input.value = '';
        render();
        if (logBtn) {
            logBtn.textContent = '✅ Logged!';
            logBtn.style.background = '#27ae60';
            setTimeout(() => {
                logBtn.textContent = '⚠️ Log Interruption';
                logBtn.style.background = '#e67e22';
            }, 1500);
        }
    }

    if (logBtn) logBtn.addEventListener('click', logInterruption);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') logInterruption(); });
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (!confirm('Clear all interruptions?')) return;
            interruptions = [];
            localStorage.setItem('interruptionLog', JSON.stringify(interruptions));
            render();
        });
    }
    render();
})();

// ----- SOUNDBOARD (Web Audio – Rain, Cyber, White) -----
(function initSoundboard() {
    const soundBtns = document.querySelectorAll('.sound-btn');
    const volumeSlider = document.getElementById('master-volume');
    const soundIndicator = document.getElementById('sound-indicator');

    if (!soundBtns.length) return;

    let audioCtx = null;
    let activeNodes = [];
    let activeSound = null;
    let masterGain = null;

    function initAudio() {
        if (audioCtx) return;
        audioCtx = new(window.AudioContext || window.webkitAudioContext)();
        masterGain = audioCtx.createGain();
        masterGain.gain.value = 0.6;
        masterGain.connect(audioCtx.destination);
    }

    function stopCurrent() {
        activeNodes.forEach(node => {
            try { node.stop ? node.stop() : node.disconnect(); } catch (e) {}
        });
        activeNodes = [];
        activeSound = null;
        if (soundIndicator) soundIndicator.textContent = '⏸ Idle';
        soundBtns.forEach(b => b.style.borderColor = '');
    }

    function playRain() {
        stopCurrent();
        initAudio();
        activeSound = 'rain';
        const bufferSize = audioCtx.sampleRate * 2;
        const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(Math.random(), 2);
        const source = audioCtx.createBufferSource();
        source.buffer = buffer;
        source.loop = true;
        const filter = audioCtx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 1200;
        filter.Q.value = 0.8;
        const gain = audioCtx.createGain();
        gain.gain.value = 0.35;
        const lfo = audioCtx.createOscillator();
        lfo.frequency.value = 3.2;
        const lfoGain = audioCtx.createGain();
        lfoGain.gain.value = 0.12;
        const lfoOffset = audioCtx.createConstantSource();
        lfoOffset.offset.value = 0.35;
        lfo.connect(lfoGain);
        lfoGain.connect(gain.gain);
        lfoOffset.connect(gain.gain);
        source.connect(filter);
        filter.connect(gain);
        gain.connect(masterGain);
        source.start();
        lfo.start();
        lfoOffset.start();
        activeNodes = [source, filter, gain, lfo, lfoGain, lfoOffset];
        if (soundIndicator) soundIndicator.textContent = '🌧 Rain';
        document.querySelector('.sound-btn[data-sound="rain"]').style.borderColor = '#88c0d0';
    }

    function playCyber() {
        stopCurrent();
        initAudio();
        activeSound = 'cyber';
        const baseFreq = 110;
        const nodes = [];
        [baseFreq * 0.998, baseFreq * 1.002, baseFreq * 2.001].forEach((freq, i) => {
            const osc = audioCtx.createOscillator();
            osc.type = 'sawtooth';
            osc.frequency.value = freq;
            const gain = audioCtx.createGain();
            gain.gain.value = i === 2 ? 0.06 : 0.15;
            const filter = audioCtx.createBiquadFilter();
            filter.type = 'lowpass';
            filter.frequency.value = 180 + (i * 40);
            filter.Q.value = 1.5;
            osc.connect(filter);
            filter.connect(gain);
            gain.connect(masterGain);
            osc.start();
            nodes.push(osc, gain, filter);
        });
        const sweepLFO = audioCtx.createOscillator();
        sweepLFO.frequency.value = 0.4;
        const sweepGain = audioCtx.createGain();
        sweepGain.gain.value = 80;
        sweepLFO.connect(sweepGain);
        if (nodes.length >= 3) sweepGain.connect(nodes[2].frequency);
        sweepLFO.start();
        // noise layer
        const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * 0.5, audioCtx.sampleRate);
        const d = buf.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * 0.2;
        const ns = audioCtx.createBufferSource();
        ns.buffer = buf;
        ns.loop = true;
        const ng = audioCtx.createGain();
        ng.gain.value = 0.03;
        ns.connect(ng);
        ng.connect(masterGain);
        ns.start();
        activeNodes = [...nodes, sweepLFO, sweepGain, ns, ng];
        if (soundIndicator) soundIndicator.textContent = '🛸 Cyber';
        document.querySelector('.sound-btn[data-sound="cyber"]').style.borderColor = '#c084d0';
    }

    function playNoise() {
        stopCurrent();
        initAudio();
        activeSound = 'noise';
        const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * 1, audioCtx.sampleRate);
        const d = buf.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * 0.4;
        const source = audioCtx.createBufferSource();
        source.buffer = buf;
        source.loop = true;
        const filter = audioCtx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 800;
        filter.Q.value = 0.6;
        const gain = audioCtx.createGain();
        gain.gain.value = 0.25;
        source.connect(filter);
        filter.connect(gain);
        gain.connect(masterGain);
        source.start();
        activeNodes = [source, filter, gain];
        if (soundIndicator) soundIndicator.textContent = '🌊 White';
        document.querySelector('.sound-btn[data-sound="noise"]').style.borderColor = '#aaaaaa';
    }

    soundBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            initAudio();
            if (activeSound === btn.dataset.sound) { stopCurrent(); return; }
            switch (btn.dataset.sound) {
                case 'rain': playRain(); break;
                case 'cyber': playCyber(); break;
                case 'noise': playNoise(); break;
                default: stopCurrent();
            }
        });
    });

    if (volumeSlider) {
        volumeSlider.addEventListener('input', (e) => {
            if (masterGain) masterGain.gain.value = parseInt(e.target.value) / 100;
        });
    }

    // Init audio on first click
    document.addEventListener('click', initAudio, { once: true });
})();

