// ============================================================
// TIMER UI – Binds buttons, presets, keyboard shortcuts
// ============================================================

function initTimerUI() {
    // Guard against duplicate initialisation
    if (window._timerUIInitialized) {
        console.warn('Timer UI already initialized, skipping duplicate.');
        return;
    }
    window._timerUIInitialized = true;
    console.log('✅ Timer UI initializing...');

    // ----- DOM REFS -----
    const timerStartBtn = document.getElementById('focusTimerStartBtn');
    const timerResetBtn = document.getElementById('focusTimerResetBtn');
    const panicBtn = document.getElementById('panic-btn');
    const presetBtns = document.querySelectorAll('.timer-preset');
    const sessionLabelInput = document.getElementById('session-label');
    const scheduledInput = document.getElementById('scheduled-minutes');
    const linkedTaskLabel = document.getElementById('focusTimerTask');

    // ----- START / PAUSE -----
    if (timerStartBtn) {
        timerStartBtn.addEventListener('click', () => {
            if (typeof window.toggleTimer === 'function') {
                window.toggleTimer();
            }
        });
    }

    // ----- RESET -----
    if (timerResetBtn) {
        timerResetBtn.addEventListener('click', () => {
            if (typeof window.resetTimer === 'function') {
                window.resetTimer();
            }
        });
    }

    // ----- PANIC +5 MIN -----
    if (panicBtn) {
        panicBtn.addEventListener('click', () => {
            if (typeof window.currentMinutes !== 'undefined') {
                window.currentMinutes += 5;
                if (typeof window.updateTimerDisplay === 'function') {
                    window.updateTimerDisplay();
                }
                const display = document.getElementById('focusTimerDisplay');
                if (display) {
                    display.style.color = '#f39c12';
                    setTimeout(() => { display.style.color = ''; }, 400);
                }
            }
        });
    }

    // ----- PRESETS -----
    presetBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const mins = parseInt(btn.dataset.minutes);
            const label = btn.textContent.trim();
            if (typeof window.setPreset === 'function') {
                window.setPreset(mins, label);
            }
        });
    });

    // ----- SESSION LABEL -----
    if (sessionLabelInput) {
        sessionLabelInput.addEventListener('input', () => {
            if (linkedTaskLabel) {
                linkedTaskLabel.textContent = `Linked to: ${sessionLabelInput.value || 'Untitled'}`;
            }
            if (typeof updateSnippets === 'function') updateSnippets(sessionLabelInput.value);
        });
        // Set initial label
        if (linkedTaskLabel) {
            linkedTaskLabel.textContent = `Linked to: ${sessionLabelInput.value || 'Untitled'}`;
        }
    }

    // ----- SCHEDULED INPUT -----
    if (scheduledInput) {
        scheduledInput.addEventListener('change', () => {
            if (typeof window.updateAccumulatorDisplay === 'function') {
                window.updateAccumulatorDisplay();
            }
        });
    }

    // ----- KEYBOARD SHORTCUTS (Space, R, 1,2,3, Esc) -----
    document.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) return;
        switch (e.key) {
            case ' ':
                e.preventDefault();
                if (typeof window.toggleTimer === 'function') window.toggleTimer();
                break;
            case 'r':
            case 'R':
                e.preventDefault();
                if (typeof window.resetTimer === 'function') window.resetTimer();
                break;
            case '1':
                e.preventDefault();
                if (typeof window.setPreset === 'function') window.setPreset(25, 'Focus Session');
                break;
            case '2':
                e.preventDefault();
                if (typeof window.setPreset === 'function') window.setPreset(5, 'Short Break');
                break;
            case '3':
                e.preventDefault();
                if (typeof window.setPreset === 'function') window.setPreset(50, 'Deep Study');
                break;
            case 'Escape':
                if (document.getElementById('diagramModal')?.style.display === 'flex') {
                    closeDayDiagram();
                }
                break;
        }
    });

    console.log('✅ Timer UI fully bound.');
}

// ----- SNIPPET UPDATER (bonus) -----
function updateSnippets(label) {
    const box = document.getElementById('snippet-content');
    if (!box) return;
    const lower = label.toLowerCase();
    if (lower.includes('code') || lower.includes('javascript') || lower.includes('python') || lower.includes('c++')) {
        box.textContent = '>>> print("Deep Focus Mode Active!")\n// Write clean code.';
    } else if (lower.includes('phys') || lower.includes('math') || lower.includes('science')) {
        box.textContent = '📐 F = ma\n⚡ V = IR\n🧲 E = mc²';
    } else {
        box.textContent = '📝 Set your session label to see relevant snippets.';
    }
}

// ----- AUTO-START ON DOM READY -----
document.addEventListener('DOMContentLoaded', () => {
    initTimerUI();
});

// Expose for manual calls
window.initTimerUI = initTimerUI;
window.updateSnippets = updateSnippets;
