// Temporary initializer for missing globals (prevents ReferenceError in dev)
(function(){
    function safeParse(key, fallback) {
        try {
            const raw = localStorage.getItem(key);
            if (!raw) return fallback;
            const parsed = JSON.parse(raw);
            return parsed == null ? fallback : parsed;
        } catch (_) {
            return fallback;
        }
    }

    window.events = window.events || safeParse('scheduleEvents', []);
    window.libraryItems = window.libraryItems || safeParse('libraryItems', []);
    window.habits = window.habits || safeParse('habits', []);
    window.myTasks = window.myTasks || safeParse('myTasks', []);
    window.taskTemplates = window.taskTemplates || safeParse('taskTemplates', []);
    window.dashTodos = window.dashTodos || safeParse('dashTodos', []) || [];

    window.getTodayName = window.getTodayName || function() {
        return new Date().toLocaleDateString('en-US', { weekday: 'long' });
    };

    // Minimal getSessionSnapshot stub — real implementation lives in schedule-core.js
    window.getSessionSnapshot = window.getSessionSnapshot || function() {
        const todayEvents = (window.events || []).filter(e => {
            try { return e.day === window.getTodayName(); } catch(_) { return false; }
        }).sort((a,b)=> (a.start||'').localeCompare(b.start||''));
        return {
            current: todayEvents.length ? todayEvents[0] : null,
            next: todayEvents.length > 1 ? todayEvents[1] : null,
            todayEvents
        };
    };

    console.log('init-globals: ensured events and related arrays exist', {
        eventsLength: (window.events||[]).length,
        libraryItemsLength: (window.libraryItems||[]).length,
        dashTodosLength: (window.dashTodos||[]).length
    });
})();
