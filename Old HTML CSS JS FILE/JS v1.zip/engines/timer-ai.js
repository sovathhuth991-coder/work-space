// ============================================================
// TIMER AI ASSISTANT (Ollama) – Fully Isolated Module
// ============================================================

// ----- AI STATE -----
let aiHistory = [];
let aiLoading = false;
let lastSuggestionTime = 0;
let suggestionInterval = null;
const AI_HISTORY_KEY = 'aiChatHistory';
const OLLAMA_URL = 'http://localhost:11434/api/generate';
const OLLAMA_MODEL = 'qwen2.5:7b'; // ← CHANGE to your exact model name from 'ollama list'

// ----- DOM REFS (Sidebar AI) -----
const aiMessagesSide = document.getElementById('ai-messages-side');
const aiInputSide = document.getElementById('ai-input-side');
const aiSendSide = document.getElementById('ai-send-side');
const aiStatusSide = document.getElementById('ai-status-side');
const aiModelNameSide = document.getElementById('ai-model-name-side');

// ============================================================
// 1. CONTEXT BUILDER (reads lessons, tasks, notes, schedule)
// ============================================================
function getWorkspaceContext() {
    const sessionLabel = document.getElementById('session-label')?.value || 'Unknown';
    const scheduled = parseInt(document.getElementById('scheduled-minutes')?.value) || 0;
    const accumMins = Math.floor((parseInt(localStorage.getItem('focusAccumulatorSeconds')) || 0) / 60);
    const timerRunning = window.isTimerRunning ? 'running' : 'paused/idle';

    // Read active lesson
    let activeLessonTitle = 'None';
    let pageContent = '';
    const headline = document.getElementById('active-page-headline');
    if (headline) {
        const title = headline.textContent.trim();
        if (title !== 'Select a page from the tree view to open a workspace') {
            activeLessonTitle = title;
            const editor = document.getElementById('live-ledger-output');
            if (editor) {
                pageContent = editor.textContent || '';
                if (pageContent.length > 3000) pageContent = pageContent.substring(0, 3000) + '... (truncated)';
            }
        }
    }

    // Read tasks
    let tasks = [];
    try {
        const todoData = JSON.parse(localStorage.getItem('todoList') || '[]');
        tasks = todoData.filter(t => !t.done).map(t => t.text).slice(0, 5);
    } catch (e) {}

    // Read notes
    let notes = [];
    try {
        const noteData = JSON.parse(localStorage.getItem('floatingNotesData') || '[]');
        notes = noteData.slice(-3).map(n => n.text);
    } catch (e) {}

    // Read schedule (today's tasks)
    let todayTasks = [];
    try {
        const schedule = JSON.parse(localStorage.getItem('scheduleData') || '[]');
        const today = new Date().toISOString().split('T')[0];
        todayTasks = schedule
            .filter(e => e.date === today)
            .map(e => e.title)
            .slice(0, 5);
    } catch (e) {}

    return {
        sessionLabel,
        scheduled,
        accumulatedMins: accumMins,
        timerRunning,
        activeLessonTitle,
        pageContent,
        tasks,
        notes,
        todayTasks,
        timestamp: new Date().toLocaleString()
    };
}

// ============================================================
// 2. AI CORE FUNCTIONS
// ============================================================
function renderAiMessages() {
    if (!aiMessagesSide) return;
    if (aiHistory.length === 0) {
        aiMessagesSide.innerHTML = `<div style="text-align:center; opacity:0.4; padding:6px 0; font-size:11px;">Ask me anything.</div>`;
        return;
    }
    let html = '';
    aiHistory.forEach(msg => {
        const cls = msg.role === 'user' ? 'msg-user' : 'msg-assistant';
        const badge = msg.auto ? '<span class="auto-badge">Auto-Suggestion</span>' : '';
        html += `<div class="${cls}"><div class="bubble">${badge}${escapeHtml(msg.content)}</div></div>`;
    });
    aiMessagesSide.innerHTML = html;
    aiMessagesSide.scrollTop = aiMessagesSide.scrollHeight;
}

function updateAiStatus(state) {
    if (!aiStatusSide) return;
    const text = state === 'online' ? '● online' :
        state === 'thinking' ? '● thinking...' :
        '● offline';
    aiStatusSide.textContent = text;
    aiStatusSide.className = 'status ' + state;
}

function loadAiHistory() {
    try {
        const stored = localStorage.getItem(AI_HISTORY_KEY);
        aiHistory = stored ? JSON.parse(stored) : [];
    } catch (e) { aiHistory = []; }
    renderAiMessages();
}

function saveAiHistory() {
    localStorage.setItem(AI_HISTORY_KEY, JSON.stringify(aiHistory));
}

async function checkOllamaHealth() {
    try {
        const res = await fetch('http://localhost:11434/api/tags', { method: 'GET' });
        if (res.ok) {
            updateAiStatus('online');
            if (aiModelNameSide) aiModelNameSide.textContent = OLLAMA_MODEL;
        } else {
            updateAiStatus('offline');
        }
    } catch {
        updateAiStatus('offline');
    }
}

// ----- MAIN SEND FUNCTION -----
async function sendAiMessage(prompt, silent = false, auto = false) {
    if (!prompt.trim() || aiLoading) return;
    aiLoading = true;
    if (aiSendSide) aiSendSide.disabled = true;
    updateAiStatus('thinking');

    if (!silent) {
        aiHistory.push({ role: 'user', content: prompt.trim() });
    } else {
        aiHistory.push({ role: 'user', content: '💡 System: Please provide a proactive suggestion.' });
    }
    saveAiHistory();
    renderAiMessages();

    if (!silent && aiInputSide) aiInputSide.value = '';

    const context = getWorkspaceContext();
    const systemPrompt = `
You are a proactive, helpful AI assistant embedded in a productivity workspace.

CURRENT WORKSPACE CONTEXT:
- Session Label: "${context.sessionLabel}"
- Scheduled Time: ${context.scheduled} minutes
- Focused So Far: ${context.accumulatedMins} minutes
- Timer State: ${context.timerRunning}
- Active Lesson: "${context.activeLessonTitle}"
- Pending Tasks: ${context.tasks.length > 0 ? context.tasks.join(', ') : 'None'}
- Today's Schedule: ${context.todayTasks.length > 0 ? context.todayTasks.join(', ') : 'None'}
- Recent Notes: ${context.notes.length > 0 ? context.notes.join('; ') : 'None'}

CONTENT OF THE CURRENT LESSON PAGE:
\`\`\`
${context.pageContent || 'No lesson content open.'}
\`\`\`

INSTRUCTIONS:
1. Always respond in clear, concise English. Never switch to Chinese.
2. Use the lesson content to generate specific exercises or suggestions.
3. For auto-suggestions, keep it under 2 sentences, actionable, and do NOT ask questions back.
`;

    try {
        const resp = await fetch(OLLAMA_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: OLLAMA_MODEL,
                prompt: prompt.trim(),
                system: systemPrompt,
                stream: false,
                options: { temperature: 0.7, top_p: 0.9 }
            })
        });
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();
        const reply = data.response || 'No response.';

        aiHistory.push({ role: 'assistant', content: reply.trim(), auto: auto });
        saveAiHistory();
        renderAiMessages();
        updateAiStatus('online');
    } catch (err) {
        console.error('Ollama error:', err);
        const errMsg = `⚠️ Could not reach Ollama. Make sure it's running with: OLLAMA_ORIGINS="*" ollama serve\nModel: ${OLLAMA_MODEL}`;
        aiHistory.push({ role: 'assistant', content: errMsg, auto: false });
        saveAiHistory();
        renderAiMessages();
        updateAiStatus('offline');
    } finally {
        aiLoading = false;
        if (aiSendSide) aiSendSide.disabled = false;
    }
}

// ============================================================
// 3. AUTO-SUGGESTION ENGINE
// ============================================================
const SUGGESTION_INTERVAL_MS = 60000;
const SUGGESTION_TRIGGER_MINUTES = 5;

async function getProactiveSuggestion() {
    if (aiLoading) return;
    const context = getWorkspaceContext();
    if (!context.pageContent && context.tasks.length === 0 && context.notes.length === 0) return;

    const now = Date.now();
    if (now - lastSuggestionTime < SUGGESTION_INTERVAL_MS) return;
    lastSuggestionTime = now;

    const prompt = `Based on my current context (session: ${context.sessionLabel}, focus: ${context.accumulatedMins} min, active lesson: "${context.activeLessonTitle}"), give me ONE actionable, specific suggestion for what to do next. Keep it under 20 words. Do not ask me questions. Just give the suggestion.`;
    await sendAiMessage(prompt, true, true);
}

function startAutoSuggestions() {
    stopAutoSuggestions();
    // First suggestion after 10 seconds of focus
    setTimeout(() => {
        if (window.isTimerRunning) getProactiveSuggestion();
    }, 10000);

    // Then every 5 minutes of accumulated focus (checked via interval)
    suggestionInterval = setInterval(() => {
        if (window.isTimerRunning) {
            const accumMins = Math.floor((parseInt(localStorage.getItem('focusAccumulatorSeconds')) || 0) / 60);
            // Suggest every 5 minutes
            if (accumMins % SUGGESTION_TRIGGER_MINUTES === 0 && accumMins > 0) {
                // Avoid duplicate at exact zero
                getProactiveSuggestion();
            }
        }
    }, 30000); // check every 30 seconds
}

function stopAutoSuggestions() {
    if (suggestionInterval) {
        clearInterval(suggestionInterval);
        suggestionInterval = null;
    }
}

// ============================================================
// 4. AI INITIALIZATION
// ============================================================
function initAI() {
    console.log('🧠 AI Module initializing...');

    // AI Send button
    if (aiSendSide) {
        aiSendSide.addEventListener('click', () => {
            sendAiMessage(aiInputSide.value, false, false);
        });
    }

    // AI Input Enter key
    if (aiInputSide) {
        aiInputSide.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                sendAiMessage(aiInputSide.value, false, false);
            }
        });
    }

    // Load AI history
    loadAiHistory();

    // Health check
    checkOllamaHealth();

    console.log('✅ AI Module initialized.');
}

// ============================================================
// 5. EXPOSE AI API GLOBALLY
// ============================================================
window.ai = {
    getProactiveSuggestion,
    sendAiMessage,
    loadAiHistory,
    saveAiHistory,
    checkOllamaHealth,
    startAutoSuggestions,
    stopAutoSuggestions,
    getWorkspaceContext,
    renderAiMessages,
    updateAiStatus,
    aiHistory,
    OLLAMA_MODEL
};
