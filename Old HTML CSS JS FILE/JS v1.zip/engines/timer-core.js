// ============================================================
// TIMER CORE – Pure Timer Engine (No AI, No UI Bindings)
// ============================================================

// ----- STATE -----
let isRunning = false;
let timerInterval = null;
let currentMinutes = 25;
let currentSeconds = 0;
let accumulatedSeconds = 0;
const ACCUMULATOR_KEY = 'focusAccumulatorSeconds';

// ----- DOM REFS (core display) -----
const timerDisplay = document.getElementById('focusTimerDisplay');
const timerModeLabel = document.getElementById('focusTimerMode');
const timerStartBtn = document.getElementById('focusTimerStartBtn');
const timerResetBtn = document.getElementById('focusTimerResetBtn');
const accumulatedDisplay = document.getElementById('accumulated-display');
const progressBar = document.getElementById('progress-bar');
const progressPercent = document.getElementById('progress-percent');
const scheduledDisplay = document.getElementById('scheduled-display');
const scheduledInput = document.getElementById('scheduled-minutes');

// ----- CORE FUNCTIONS -----
function updateTimerDisplay() {
    const m = String(currentMinutes).padStart(2, '0');
    const s = String(currentSeconds).padStart(2, '0');
    if (timerDisplay) timerDisplay.textContent = `${m}:${s}`;
}

function updateAccumulatorDisplay() {
    if (!accumulatedDisplay) return;
    const total = accumulatedSeconds;
    const mins = String(Math.floor(total / 60)).padStart(2, '0');
    const secs = String(total % 60).padStart(2, '0');
    accumulatedDisplay.textContent = `${mins}:${secs}`;
    const scheduled = parseInt(scheduledInput?.value) || 120;
    const scheduledSecs = scheduled * 60;
    const pct = Math.min((total / scheduledSecs) * 100, 100);
    if (progressBar) progressBar.style.width = pct + '%';
    if (progressPercent) progressPercent.textContent = Math.round(pct) + '%';
    if (scheduledDisplay) scheduledDisplay.textContent = scheduled;
    localStorage.setItem(ACCUMULATOR_KEY, String(accumulatedSeconds));
}

function timerCompleteBeep() {
    try {
        const ctx = new(window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 880;
        osc.type = 'square';
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.5);
        setTimeout(() => {
            const osc2 = ctx.createOscillator();
            const gain2 = ctx.createGain();
            osc2.connect(gain2);
            gain2.connect(ctx.destination);
            osc2.frequency.value = 880;
            osc2.type = 'square';
            gain2.gain.setValueAtTime(0.3, ctx.currentTime);
            gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
            osc2.start(ctx.currentTime);
            osc2.stop(ctx.currentTime + 0.3);
        }, 200);
    } catch (e) { /* silent */ }
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('✅ Session Complete!', { body: 'Great work!' });
    } else if ('Notification' in window && Notification.permission !== 'denied') {
        Notification.requestPermission();
    }
}

function toggleTimer() {
    if (isRunning) {
        // PAUSE
        clearInterval(timerInterval);
        timerInterval = null;
        isRunning = false;
        if (timerStartBtn) timerStartBtn.textContent = 'Resume';
        if (timerModeLabel) timerModeLabel.textContent = 'Paused';
        // Stop auto-suggestions if AI is loaded
        if (window.ai && typeof window.ai.stopAutoSuggestions === 'function') {
            window.ai.stopAutoSuggestions();
        }
        return;
    }

    // START / RESUME
    if (currentMinutes === 0 && currentSeconds === 0) {
        currentMinutes = 25;
        currentSeconds = 0;
    }
    isRunning = true;
    if (timerStartBtn) timerStartBtn.textContent = 'Pause';
    if (timerModeLabel) timerModeLabel.textContent = 'Focus Session';

    timerInterval = setInterval(() => {
        if (currentSeconds === 0) {
            if (currentMinutes === 0) {
                // TIMER COMPLETE
                clearInterval(timerInterval);
                timerInterval = null;
                isRunning = false;
                if (timerStartBtn) timerStartBtn.textContent = 'Start';
                if (timerModeLabel) timerModeLabel.textContent = 'Done 🎯';
                updateTimerDisplay();
                timerCompleteBeep();
                // Trigger AI suggestion if available
                if (window.ai && typeof window.ai.getProactiveSuggestion === 'function') {
                    setTimeout(() => window.ai.getProactiveSuggestion(), 1500);
                }
                return;
            }
            currentMinutes--;
            currentSeconds = 59;
        } else {
            currentSeconds--;
        }
        accumulatedSeconds++;
        updateTimerDisplay();
        updateAccumulatorDisplay();
    }, 1000);

    // Start auto-suggestions if AI is loaded
    if (window.ai && typeof window.ai.startAutoSuggestions === 'function') {
        window.ai.startAutoSuggestions();
    }
}

function resetTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
    isRunning = false;
    if (timerStartBtn) timerStartBtn.textContent = 'Start';
    if (timerModeLabel) timerModeLabel.textContent = 'Focus Session';
    currentMinutes = 25;
    currentSeconds = 0;
    updateTimerDisplay();
    if (window.ai && typeof window.ai.stopAutoSuggestions === 'function') {
        window.ai.stopAutoSuggestions();
    }
}

function setPreset(minutes, label) {
    if (isRunning) {
        clearInterval(timerInterval);
        timerInterval = null;
        isRunning = false;
        if (timerStartBtn) timerStartBtn.textContent = 'Start';
        if (window.ai && typeof window.ai.stopAutoSuggestions === 'function') {
            window.ai.stopAutoSuggestions();
        }
    }
    currentMinutes = minutes;
    currentSeconds = 0;
    if (timerModeLabel) timerModeLabel.textContent = label || 'Focus Session';
    updateTimerDisplay();
    document.querySelectorAll('.timer-preset').forEach(b => b.classList.remove('active-preset'));
    document.querySelector(`.timer-preset[data-minutes="${minutes}"]`)?.classList.add('active-preset');
}

// ----- LOAD SAVED ACCUMULATOR ON START -----
const savedAcc = localStorage.getItem(ACCUMULATOR_KEY);
if (savedAcc) accumulatedSeconds = parseInt(savedAcc) || 0;
updateAccumulatorDisplay();
updateTimerDisplay();

// ----- EXPOSE CORE FUNCTIONS GLOBALLY -----
window.toggleTimer = toggleTimer;
window.resetTimer = resetTimer;
window.setPreset = setPreset;
window.updateTimerDisplay = updateTimerDisplay;
window.updateAccumulatorDisplay = updateAccumulatorDisplay;
window.currentMinutes = currentMinutes;
window.currentSeconds = currentSeconds;
window.isRunning = isRunning;
window.accumulatedSeconds = accumulatedSeconds;
