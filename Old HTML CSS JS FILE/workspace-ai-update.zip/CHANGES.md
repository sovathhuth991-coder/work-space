# AI Assistant relocation + site sync + sidebar declutter

## How to apply
1. Delete `WorkspaceShared/ai-assistant.js` from your repo — it's been replaced.
2. Copy the files in this zip into your repo, preserving folder structure
   (this creates the new `WorkspaceFeatures/ai-assistant/` folder and
   overwrites `index.html`, `WorkspaceCore/app.js`, `WorkspaceCore/layout.css`,
   `WorkspaceCore/variables.css`).
3. Open in a browser and check the console for errors. No other files were touched.

## 1. AI Assistant → its own nav item + full view
- New nav button "🧠 AI Assistant" in the sidebar, right under Dashboard.
- New `ai-view` section with a real chat panel (not a 120px box) plus a
  "What I can see" / "What I can do" side panel.
- Moved out of `WorkspaceShared/` into `WorkspaceFeatures/ai-assistant/`
  (context.js, tools.js, assistant.js, assistant.css) — matches your
  three-tier structure since it's now a full feature, not a shared widget.

## 2. Sidebar decluttering
- Root cause of the "cramped" nav: the old AI chat box (status + 120px
  message list + input) lived in the sidebar footer, which is fixed-height,
  squeezing the scrollable nav (`.hub-menu { flex:1 }`) down to almost
  nothing — hence the tiny inner scrollbar in your screenshot. Removing it
  from the footer alone frees most of that space back to the nav.
- Nav items are now wrapped in `.hub-menu-group` containers, and the
  section-collapse feature (Main / Tools / Knowledge / Help) — which existed
  in your code but was broken (`label.nextElementSibling.nextElementSibling`
  never matched anything real) — now actually works, animates, and
  remembers collapsed state in localStorage across sessions.

## 3. Website sync (read + act on your data)
- `ai-context.js` — reads live state from `myTasks`, `habits`, `libraryItems`,
  `events`, `JournalEngine`, `ReadingListEngine` and builds a snapshot injected
  into the system prompt on every message, so the assistant always has your
  current tasks/habits/journal/reading list/library/today's schedule — no
  stale data, no separate sync step needed.
- `ai-tools.js` — defines 17 tools wired to your **real, existing** functions
  (`addMyTask`/`toggleMyTask`/`deleteMyTask`, `addHabit`/`toggleHabit`/
  `deleteHabit`, `JournalEngine.createEntry`/`deleteEntry`,
  `ReadingListEngine.add`/`update`/`delete`, library add/delete, and
  `navigate_to_view` to jump the user to any section). All `delete_*` tools
  go through a `confirm()` dialog first — same pattern your `deleteHabit`
  already uses.
- Tool-calling uses a plain fenced ` ```tool_call ` JSON convention instead
  of any one backend's native "tools" API, on purpose — Ollama, LM Studio,
  llama.cpp server, text-gen-webui, and Jan all support this equally, since
  it's just prompted text, not a special request shape. Weaker local models
  may not reliably emit it — reading your data (answering questions from the
  snapshot) works regardless; taking actions depends on the connected model
  following instructions well. There's an "Allow actions" checkbox in the
  view to turn tool-calling off entirely and use it as a read-only Q&A
  assistant if you'd rather.

## Not wired yet (by design, to keep this shippable)
Schedule/calendar event creation, Lessons, and Analytics are exposed
read-only in the snapshot but have no add/edit/delete tools yet — their
"add" flows go through the day-modal UI rather than a simple function, so
wiring them needs a bit more care. `ai-tools.js` is written so adding a new
tool is just one entry in `AI_TOOL_SCHEMAS` + one function in
`AI_TOOL_EXECUTORS` — happy to do those next if you want them.
